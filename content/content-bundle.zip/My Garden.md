👋 Welcome to my digital garden I'm Lucas. 

I am helping to build digital gardens with [`Markbase`](https://markbase.xyz/)

You can read more about me at [kohorst.fyi](https://kohorst.fyi), connect with me on [twitter](https://twitter.com/KohorstLucas), or check out what I am [reading](https://kohorst.fyi/reading) and [writing](https://kohorst.fyi/writing) 