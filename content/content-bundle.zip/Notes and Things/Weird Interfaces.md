---
title: Weird Interfaces
description: Ways to interact with an application that are not normal (web/mobile app)
twitterHandle: "@KohorstLucas"
twitterSite: "@KohorstLucas"
twitterCardType: summary_large_image
---
Type: #note
Topic: 
Tags: #interface #ui #niche

Interacting with interfaces like 
- https://12ft.io
- https://vxtwitter.com
are very interesting because their entire interface is a URL 

Also having email relays is interesting for pocket, compound, flighty etc. 

**Edited Last: 2023-02-25**