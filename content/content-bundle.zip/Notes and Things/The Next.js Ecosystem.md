---
title: Next.js Ecosystem
description: Overview of the Next.js Ecosystem
twitterHandle: "@KohorstLucas"
twitterSite: "@KohorstLucas"
twitterCardType: summary_large_image
---
Type: #note
Topic: 
Tags: #next #development #open-source

Next.js ecosystem is sprawling and very good for building websites but also for packaging, distributing, and deploying them. 

### Deployment 
- [SST](https://sst.dev/) Deploy Next.js applications easily to AWS along with https://seed.run/ 
  
```javascript
new NextjsSite(this, "site", {

 path: "src/next-app",

 customDomain: "www.my-next-app.com"

})
```

- [OpenNext](https://github.com/serverless-stack/open-next) Opensource Next.js Adapter that easily allows you to deploy applications 

### Lambda Functions 
Note that a large part of why the deployment of Next.js applications is the ability to easily use Lambda functions which can be read more about below
- https://sst.dev/chapters/what-is-aws-lambda.html
- https://sst.dev/chapters/why-create-serverless-apps.htm[]()l

**Edited Last: 2023-02-25**