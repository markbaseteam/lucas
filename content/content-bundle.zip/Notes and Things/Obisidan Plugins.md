---
title: Obsidian Plugins
description: List of Obsidian Plugins
twitterHandle: "@KohorstLucas"
twitterSite: "@KohorstLucas"
twitterCardType: summary_large_image
---
Type: #note
Topic: [[My Workflow]]
Tags: #digital-gardening #markbase #workflow 

[Obisidan](https://obsidian.md) has a rich number of unique and interesting plugins that are very helpful through the gardening and general writing process. 

There are a few essential plugins like [obsidian-git](https://github.com/denolehov/obsidian-git) or a spell checker like [langauge-to](https://obsidian.md/plugins?search=languageto#). There are also quite a few plugins, themes and other cool things in various awesome lists [1](https://github.com/kmaasrud/awesome-obsidian), [2](https://github.com/noghartt/awesome-obsidian-plugins)

Some other plugins that I regularly use and/or find interesting are 

[Obsidian Query Language](https://github.com/jplattel/obsidian-query-language) Allows you to query your notes and gather information about your vault inside a note itself

[Obsidian Terminal](https://github.com/polyipseity/obsidian-terminal) Add a terminal or command prompt direct into Obsidian

[Booksidian](https://github.com/MichaBrugger/booksidian_plugin) Connect your goodreads account into Obsidian

[Notion to Obsidian](https://github.com/Easychris/obsidian-to-notion) share a file in Obsidian into Notion

[Readwise](https://github.com/readwiseio/obsidian-readwise) Official Readwise plugin for Obsidian

[GPT3](https://github.com/micahke/obsidian-gpt3-notes) Obsidian and GPT3

[Readlater](https://github.com/Canna71/obsidian-readlater) Integrate with pocket and instapaper to store a local copy of the website that you want to read later

[Text Autocomplete](https://github.com/yeboster/autocomplete-obsidian) Autocomplete your text

[REST API](https://github.com/coddingtonbear/obsidian-local-rest-api) Turn your local vault into a REST API

[VSCode](https://github.com/NomarCub/obsidian-open-vscode) Open your vault in VScode

[RSS](https://github.com/joethei/obsidian-rss) Read and store RSS Feeds inside Obsidian

[Pluck](https://github.com/kevboh/obsidian-pluck) Quickly insert the contents of a webpage into Obsidian

[Vantage](https://github.com/ryanjamurphy/vantage-obsidian) Advanced search builder for Obsidian

[Matter](https://github.com/getmatterapp/obsidian-matter) Sync matter notes with Obsidian

[Webhooks](https://github.com/trashhalo/obsidian-webhooks) Connect Obsidian to the internet of things with webhooks

[Tweet to Obsidian](https://github.com/kbravh/obsidian-tweet-to-markdown) Convert a tweet into a markdown file

[Make](https://github.com/Make-md/makemd) Enhance your Obsidian Experience

### Publishing 
[Markbase](https://obsidian.md/plugins?id=obsidian-markbase) One Click Publish

[Obsius](https://github.com/jonstodle/obsius-obsidian-plugin) Publish individual notes

[Obsidian to Ghost](https://github.com/jaynguyens/obsidian-ghost-publish) Using `yaml` at the top of your file publish a new post to Ghost

[Micro.blog](https://github.com/otaviocc/obsidian-microblog) Obsidian to Micro.blog

[Publisher](https://github.com/ObsidianPublisher/obsidian-github-publisher) Publish your notes to a GitHub repository

[Wordpress](https://github.com/devbean/obsidian-wordpress) Publish to WordPress

[Gists](https://github.com/ghedamat/obsidian-save-as-gist) Save Obsidian Notes to Gists

**Edited Last: 2023-02-25**