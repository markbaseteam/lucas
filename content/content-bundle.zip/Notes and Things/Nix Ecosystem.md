---
title: Nix Ecosystem
description: Stuff in the Nix Ecosystem
twitterHandle: "@KohorstLucas"
twitterSite: "@KohorstLucas"
twitterCardType: summary_large_image
---
Type: #note
Topic: 
Tags: #nix #packages #dependency-management

# Nix Ecosystem

Some things that I like in the Nix ecosystem are 
- [Determinate Systems](https://determinate.systems/)
- https://zero-to-nix.com/concepts/nix

**Edited Last: 2023-02-25**