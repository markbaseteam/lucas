---
title: My Workflow
description: How I work
twitterHandle: "@KohorstLucas"
twitterSite: "@KohorstLucas"
twitterCardType: summary_large_image
---
Type: #note
Topic: [[On Digital Gardening]]
Tags: #digital-gardening #organization #workflow

# Browser 
- arc
- spaces
- tab management 

# Notifications
- always check setting first 
- try to control at system level as much as possible and then at app level for fine grained controls

# Developing 
- nix 
	- riff
- vscode 
- vim
- vaark
	- for entire environments

**Edited Last: 2023-02-25**