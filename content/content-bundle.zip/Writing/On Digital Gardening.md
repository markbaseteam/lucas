---
title: On Digital Gardening
description: Why should we digital garden
twitterHandle: "@KohorstLucas"
twitterSite: "@KohorstLucas"
twitterCardType: summary_large_image
---
Type: #note
Topic:
Tags: #knowledge #organization #markbase

**- why I like organizing and gathering niche blogs and gardens 
- Tending to them is fun and helpful but generally not worth your time 
- If a garden is well tended your productivity skyrockets 
- Some cool tools 
- Great gardens 
- Any I acquired markbase at what it is

### What you need to do to make it easy to consistently tend to the garden
- using templates for everything initially is extremely helpful in organizing and helping to update in the future 
- Having regular reminders to touch up sections and updates things 
- As you write notes about things if stuff is well tagged you will be connected to similar things 

### History 
- [Garden History from Maggie](https://maggieappleton.com/garden-history)

### Notes on Gardening
- [building wikis and tending to knowledge]([](https://tomcritchlow.com/blogchains/digital-gardens/))
- [gardening in obsidian](https://bytes.zone/posts/digital-gardening-in-obsidian/)
- [an overview](https://twitter.com/mappletons/status/1250532315459194880?s=46&t=hpS9DtC3JXKSYyhE-0aIKw)

### Tools
- [quartz]([https://quartz.jzhao.xyz](https://quartz.jzhao.xyz/))
- [awesome list of gardens](https://github.com/KasperZutterman/Second-Brain)
- [https://golden.com](https://golden.com/)

### Very Good Gardens 
- [nikita.dev all time best garden](https://wiki.nikiv.dev/)
- [resonabledeviations.com](https://reasonabledeviations.com/2022/04/18/molecular-notes-part-1/)
- [rnr for options](https://publish.obsidian.md/rnr/Index)

### Other 
- [Domestic Cozy](https://www.ribbonfarm.com/series/domestic-cozy/) 
- [The premium mediocre life](https://www.ribbonfarm.com/2017/08/17/the-premium-mediocre-life-of-maya-millennial/)
- [The garden and the stream](https://hapgood.us/2015/10/17/the-garden-and-the-stream-a-technopastoral/) 
- [On Digital Streams and Campfires](https://tomcritchlow.com/2018/10/10/of-gardens-and-wikis/)
- [Building a digital garden](https://tomcritchlow.com/2019/02/17/building-digital-garden/) 
- [Planeting new materials in my garden](https://tomcritchlow.com/2019/06/19/screenotate-wiki/) 
- [The dark Forest and the Cozy Web](https://maggieappleton.com/cozy-web) 
- [My blog is a digital garden not a blog](https://joelhooks.com/digital-garden)
- [The blogs that broke the web](https://stackingthebricks.com/how-blogs-broke-the-web/)
- [Digital Gardens TOS](https://www.swyx.io/digital-garden-tos) 
- [Digital Garden Setup](https://nesslabs.com/digital-garden-set-up) 
- [Gardens and Streams](https://indieweb.org/2020/Pop-ups/Garden-And-Stream)**

**Edited Last: 2023-02-25**