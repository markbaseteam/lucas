---
title: Selling Calls and Puts on Uniswap V3
description: Emulating option payoffs on uniswap v3, and the differences in premium and expiry
twitterHandle: "@KohorstLucas"
twitterSite: "@KohorstLucas"
twitterCardType: summary_large_image
---
Type: #article
Topic: 
Tags: #uniswap #options #cfmms
Author: Lucas Kohorst

![](https://cdn-images-1.medium.com/max/800/1*b-3asZDMVl6BFB-botH3eg.png)

Uniswap V3 allows a user to provide liquidity within specific price ranges known as a [range order](https://docs.uniswap.org/protocol/concepts/V3-overview/range-orders). For example, you could provide liquidity on ETH:USDC just within the range of $2500-$3500. Meaning you are willing to use your entire position to purchase ETH at $2500 and are willing to sell your entire position to USDC at $3500. Uniswap lists some examples of strategies that can be built with range orders like [take profit](https://docs.uniswap.org/protocol/concepts/V3-overview/range-orders#take-profit-orders) and [buy limit](https://docs.uniswap.org/protocol/concepts/V3-overview/range-orders#buy-limit-orders) orders.

First detailed in [Uniswap V3 LP Tokens as Perpetual Put and Call Options](https://lambert-guillaume.medium.com/uniswap-v3-lp-tokens-as-perpetual-put-and-call-options-5b66219db827) [Guillaume Lambert](https://medium.com/u/f1153808430) explains how Uniswap V3 liquidity positions can form payoffs similar to selling options.

> _Uniswap V3 uses the concept of_ [_ticks_](https://docs.uniswap.org/protocol/concepts/V3-overview/concentrated-liquidity#ticks) _to denoate areas between given prices, ticks are used to denote the upper and lower bounds of liquidity for a given position_

By providing liquidity across a single tick **above** the current price you will effectively be selling a call, where if your liquidity is deployed across a single tick below the current price you will effectively be selling a put.

![](https://cdn-images-1.medium.com/max/800/1*59Ns41l5wtRsfp2ozK5KZw.png)

Single tick payoff functioning like a covered call, source: [https://lambert-guillaume.medium.com/uniswap-v3-lp-tokens-as-perpetual-put-and-call-options-5b66219db827](https://lambert-guillaume.medium.com/uniswap-v3-lp-tokens-as-perpetual-put-and-call-options-5b66219db827)

**Note:** providing liquidity across multiple ticks will allow you to capture additional fees and your payoff will be curved over the ticks you are supplying.

![](https://cdn-images-1.medium.com/max/800/1*_hGWz6_-GVLpfeXdENZfEw.png)

Multiple tick payoff, curving across ticks where liquidity is supplied, source: [https://lambert-guillaume.medium.com/uniswap-v3-lp-tokens-as-perpetual-put-and-call-options-5b66219db827](https://lambert-guillaume.medium.com/uniswap-v3-lp-tokens-as-perpetual-put-and-call-options-5b66219db827)

While you can create payoffs similar to selling calls and puts on Uniswap V3 there are a few important differences.

### Premium / Fees

In Uniswap V2 you can only provide liquidity from (0, ∞) and thus you are always earning fees. In Uniswap V3 you can only earn fees when the spot price is trading between your lower and upper bounds. Meaning that if you set a single tick range you will only earn fees when the spot price tick is equal to the tick you are LPing. This is the primary difference between selling an option on Uniswap V3 vs. selling an option on a platform like [Opyn](https://opyn.co/). Rather than receiving your premium upfront (when the position is opened), you receive the premium when the price crosses above/below your position. _This can also be thought of as your option being “exercised”_.

If you are creating a covered call payoff across a single tick, fees will only be collected at that tick, and be collected **in full** meaning if you are providing liquidity to the ETH:USDC 0.3% pool you will capture 0.3% of your entire position when the price crosses over your tick. You will capture this fee **every time** the price crosses over your tick, allowing you to capture additional yield in higher volatility environments. This is the second difference, rather than capping your profit when you collect your premium, your profit is essentially unlimited (dependent on how many times your tick is crossed).

![](https://cdn-images-1.medium.com/max/800/1*ESS9HYGKxb8xKi9vudEAQA.png)

Fees (Premium) captured each time price crosses over single tick liquidity, source: [https://lambert-guillaume.medium.com/uniswap-v3-lp-tokens-as-perpetual-put-and-call-options-5b66219db827](https://lambert-guillaume.medium.com/uniswap-v3-lp-tokens-as-perpetual-put-and-call-options-5b66219db827)

### Exercising

If you are selling an American option (holders can exercise at any time before and including expiry), and the price moved above/below your call/put there would be a decent chance that you would be exercised but it is not certain. If you are selling on Uniswap V3 and expect to receive a premium, you know for sure you will be exercised.

### Expiration

Uniswap V3 options are perpetual (although not to be confused with [Everlasting Options](https://www.paradigm.xyz/2021/05/everlasting-options/), premium paid as a funding rate rather than through fees). This is the last primary difference between traditional options, but perhaps the most important. Since positions are perpetual you could sell a far out of the money call on Ethereum but never realize a premium. This is because premiums are not paid upfront and instead paid when the price crosses over the tick you are supplying on.

### Why does this matter?

Current options markets in DeFi suffer from a lack of liquidity (especially on longer tail assets) and using Uniswap V3 as a way to build option payoffs might suit the risk:reward you are looking for.

In the example where you are selling a put on ETH, you would post collateral in USDC (for a call you would post ETH). Using Uniswap V3 you can denominate either asset in **any token pair**. Meaning you could short the volatility of wBTC against ETH, or use your LINK to sell a put against UNI.

Uniswap V3 can create option payoffs for an arbitrary token pair, perpetually.

Of course, selling an option on Uniswap V3 is worse than selling an option through something like Opyn. However, there may not be enough liquidity for your position or there may not even be an options market for the pair you are looking to sell. Making selling on Uniswap V3 the next best option.

### Other Options Strategies / Thoughts

By providing single tick liquidity at a price point below the current price along with another single tick position above the current price point, you can create a short strangle payoff.

Rather than deploying two positions to create a short strangle payoff, you could provide liquidity with a lower bound being the put strike price, and the upper bound being the call strike price. Since the payoffs curve, if you are providing liquidity at the price, your payoff will look like a semi-circle.

Interestingly when selling an option on Uniswap V3, **you want to be exercised** since that is the only way that you can collect fees (your premium). Potentially the best strategy is selling an option that is crossed twice (or a multiple). Crossing above/below and then below/above will allow you to capture your fees twice on your entire position, and since the price fell back below/above your call/put you have no additional risk of impermanent loss (selling your asset too early and missing future upside).

In addition selling options on Uniswap V3 does not make much sense for far out of the money options when you consider the time value of money (unless you start selling with interest-bearing assets like stETH, or aUSDC). Rather it makes more sense to sell your options at prices decently close to spot with relatively low liquidity. So that you can capture a high percentage of the fees, with decent confidence.

Just like you would not compare an option payoff to the expected value increase of the underlying 1 to 1, you should not compare being a liquidity provider to holding the underlying. They have different risk profiles. When you provide the liquidity you are trading potential upside for decreased volatility. Similarly, when using Uniswap V3 to sell options you are trading potential upside for (somewhat) capped profit and also decreasing your risk

Visualizing liquidity providing in the framework of options can help with understanding why you might provide liquidity, the risk associated, and the potential payoffs.

### Recommended Reading

-   [Uniswap V3 LP Tokens as Perpetual Put and Call Options](https://lambert-guillaume.medium.com/uniswap-v3-lp-tokens-as-perpetual-put-and-call-options-5b66219db827)
-   [Synthetic Options and Short Calls in Uniswap V3](https://lambert-guillaume.medium.com/synthetic-options-and-short-calls-in-uniswap-v3-a3aea5e4e273)
-   [LP’ing Tradeoffs Tweet Thread](https://twitter.com/guil_lambert/status/1412608674380632067?s=20)
-   [Rebalancing vs Passive strategies for Uniswap V3 liquidity pools](https://medium.com/@DeFiScientist/rebalancing-vs-passive-strategies-for-uniswap-v3-liquidity-pools-754f033bdabc)
-   [Uniswap V3: A Quant Framework to model yield farming returns](https://medium.com/@DeFiScientist/uniswap-v3-a-quant-framework-to-model-yield-farming-returns-941a1600425e)
-   [The Replicating Portfolio of a Constant Product Market with Bounded Liquidity](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3898384)

**Edited Last: 2023-02-25**