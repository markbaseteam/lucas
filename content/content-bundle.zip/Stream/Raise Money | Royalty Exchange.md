## Link 
https://www.royaltyexchange.com/instant-offer?ads_cmpid=1011106690&ads_adid=49202678785&ads_matchtype=b&ads_network=g&ads_creative=530521216211&ads_targetid=kwd-394969080372&ttv=2&gad=1

---

23Y0516

