## Link 
**Forwarded from [Lucas Kohorst](https://t.me/lucaskohorst)**

https://www.michaeldempsey.me/blog/2023/07/18/the-dark-forest-of-rd-and-capital-deployment-in-ai/

---
[Lucas Kohorst](https://t.me/lucaskohorst)
2320230718

