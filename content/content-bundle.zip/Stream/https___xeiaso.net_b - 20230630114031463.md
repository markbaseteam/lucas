## Link 
https://xeiaso.net/blog/gophercon-eu-demo

---

23Y0630

