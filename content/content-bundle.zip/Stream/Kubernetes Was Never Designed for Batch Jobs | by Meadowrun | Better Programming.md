## Link 
https://betterprogramming.pub/kubernetes-was-never-designed-for-batch-jobs-f59be376a338

---

23Y0601

