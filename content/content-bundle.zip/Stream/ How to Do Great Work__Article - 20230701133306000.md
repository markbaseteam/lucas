## Link 
**Forwarded from [RSS Feeds](https://t.me/c/1823906798/15983)**

[](http://paulgraham.com/greatwork.html) **How to Do Great Work**

Article URL: http://paulgraham.com/greatwork.html
Comments URL: https://news.ycombinator.com/item?id=36550615
Points: 155
# Comments: 70

[Open Link »](http://paulgraham.com/greatwork.html)

---
[RSS Feeds](https://t.me/c/1823906798/15983)
2320230701

