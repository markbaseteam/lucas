## Link 
https://theanarchistlibrary.org/library/ted-kaczynski-ship-of-fools

---

23Y0611