## Link 
https://manual.withcompound.com/chapters/founders-guide-to-buying-a-house?collection=all&utm_source=twitter&utm_medium=social&utm_campaign=organic

---

23Y0516

