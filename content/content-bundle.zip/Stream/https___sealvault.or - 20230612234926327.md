## Link 
https://sealvault.org/blog/2023/04/token-transfer-tla/

---

23Y0612

