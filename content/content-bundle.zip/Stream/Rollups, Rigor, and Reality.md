## Link 
https://kelvinfichter.com/pages/thoughts/rrr/

---

23Y0530

