## Link 
https://vitalik.ca/general/2023/06/20/deeperdive.html

---
[defiprime](https://t.me/defiprime)
23Y0620

