## Link 
https://medium.com/vybe-blog/the-making-of-a-super-app-919e289e91c8

---

23Y0622

