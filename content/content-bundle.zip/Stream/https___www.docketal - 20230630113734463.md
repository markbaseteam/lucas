## Link 
https://www.docketalarm.com/cases/New_York_Southern_District_Court/1--17-cv-03533/KCG_Holdings_Inc._et_al_v._Khandekar/docs/116.pdf

---

23Y0630

