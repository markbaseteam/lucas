## Link 
https://www8.gsb.columbia.edu/sites/valueinvesting/files/files/DOC029%281%29.pdf

---

23Y0621

