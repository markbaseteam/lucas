## Link 
https://www.galaxy.com/galaxyperspectives/distribution-of-mev-surplus/

---

23Y0605

