## Link 
https://www.kaspersky.com/blog/fake-trezor-hardware-crypto-wallet/48155/

---

23Y0515

