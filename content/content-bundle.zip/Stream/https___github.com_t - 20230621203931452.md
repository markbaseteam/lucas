## Link 
https://github.com/tigerbeetledb/tigerbeetle/blob/main/docs/TIGER_STYLE.md

---

23Y0621

