## Link 
https://medium.com/@colludingnode/an-alternative-path-cf62f50fab87

---

23Y0619

