## Link 
https://dydx.exchange/blog/v4-technical-architecture-overview

---

23Y0517

