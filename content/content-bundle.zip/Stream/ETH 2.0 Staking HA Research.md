## Link 
https://coda.io/d/ETH-2-0-Staking-HA-Research_dvlQsXOm3x0

---

23Y0608

