## Link 
https://sequence.xyz/blog/sequence-wallet-light-state-sync-full-merkle-wallets

---

23Y0621

