## Link 
https://medium.com/optyfi/understanding-risks-in-defi-84a0b9c08e98?s=35

---
[defiprime](https://t.me/defiprime)
23Y0609

