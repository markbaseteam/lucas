## Link 
**Forwarded from [Lucas Kohorst](https://t.me/lucaskohorst)**

https://terraformindustries.wordpress.com/2023/06/26/the-terraformer-mark-one/

---
[Lucas Kohorst](https://t.me/lucaskohorst)
2320230827

