,## Link 
https://medium.com/chainargos/dcg-filings-analysis-b96818abfec

---

23Y0604

