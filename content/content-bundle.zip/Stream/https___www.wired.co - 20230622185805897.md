## Link 
https://www.wired.com/story/generative-ai-podcasts-boring/

---

23Y0622

